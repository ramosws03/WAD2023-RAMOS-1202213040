  <!-- Nav -->
  <nav class="navbar navbar-expand navbar-dark bg-primary">
    <div class="container py-2">
      <div class="navbar-nav justify-content-between w-100">
        <a class="nav-link active" href="/" aria-current="page">Home</a>
        <div class="d-flex">
          <a class="nav-link" href="{{ route('showroom.create') }}">Add</a>
          <a class="nav-link" href="{{ route('showroom.index') }}">List</a>
        </div>
      </div>
    </div>
  </nav>
  <!-- Nav End -->
